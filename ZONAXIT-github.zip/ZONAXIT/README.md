# ZONAXIT — painel de controle do jogo + login por e-mail e senha

O cadastro usa **nome completo, e-mail e senha**; o login usa **e-mail e senha**, com "Esqueci minha senha".
Não há login social nem telefone. O banco SQLite fica em `data/zonaxit.db`. Se existir um banco da versão por telefone,
ele é **preservado** como tabela `users_legacy_phone` (essas contas não entram por e-mail) e a tabela nova é criada.

## Painel e conexão com o seu jogo
O painel **não inclui nenhum jogo**. Os interruptores guardam as suas escolhas no navegador e as enviam a um jogo
que você conecte. Sem jogo conectado, o status no topo mostra **JOGO OFFLINE** e o botão **APLICAR NO JOGO** responde
"Nenhum jogo conectado". Nada é simulado.

Chaves enviadas ao jogo: `headSnap` `aimAssist` `alwaysHeadshot` `lightAim` `espBoxes` `espHealth` `espSkeleton`
`espNames` `stretch` `aimbot` `aimLine` `aimbotLite` `fps120` `fps60` `seeThroughWalls` `iceInvert` `iceAuto`
(booleanos), `fov` (0 a 360) e `aimTarget` (`"head"` ou `"neck"`). Os limites de FPS são exclusivos: ligar um desliga o outro.

**Botão APLICAR NO JOGO:** envia todas as opções, espera a confirmação do jogo (até 2,5 s) e compara o estado confirmado
com o pedido. Mostra sucesso, falha parcial (com o motivo de cada opção) ou erro claro ("Nenhum jogo conectado",
"O jogo não respondeu"). Os interruptores também enviam na hora quando há jogo conectado.

**Removidas por não terem função num jogo offline:** *ANT BAN* e *Disfarçado* (evasão de banimento/detecção).

## Ligar o SEU jogo
O painel fala com qualquer página **do mesmo site** que implemente a ponte `BroadcastChannel("zonaxit-bridge")`:

    painel -> jogo : {t:"ping"} | {t:"apply", seq, settings:{chave:valor}}
    jogo -> painel : {t:"hello", game, version, supports:[chaves]}      (ao abrir e a cada ping)
                     {t:"ack", seq, applied:[], rejected:{chave:motivo}, settings:{estado atual}}

O `hello` em resposta ao `ping` (a cada 3 s) mantém o status em **JOGO CONECTADO**; sem ele por 7 s volta a OFFLINE.
Opções que o seu jogo não listar em `supports` ficam desativadas no painel. Um app nativo ou um jogo em outro domínio
precisa de uma interface própria (a ponte acima, ou um WebSocket/API que você implemente).
O painel não acessa, modifica nem se conecta a nenhum programa externo.

## Instalação e execução
Requisito: **Node.js 22.9 ou mais novo** (confira com `node -v`). O projeto **não tem dependências**: não existe
`npm install` nem `node_modules`.

### Desenvolvimento local (HTTP, sem e-mail real)
    git clone <url-do-repositório> zonaxit
    cd zonaxit
    cp .env.example .env
    # No .env: troque NODE_ENV=production por NODE_ENV=development (os cookies seguros exigem HTTPS)
    # e deixe SMTP_* vazio: o código de recuperação aparece no terminal como [DEV-MAIL].
    npm start
    # abra http://127.0.0.1:3000

Fora de produção, sem `APP_SECRET` o servidor usa um segredo temporário (as sessões caem ao reiniciar).
Para fixar um, gere e cole no `.env`:

    node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

### Produção
`NODE_ENV=production`, `APP_SECRET` definido (sem ele o servidor não inicia), site atrás de **HTTPS** e SMTP configurado
(veja "E-mail de recuperação"). Detalhes em "Publicar".

### Testes
    npm test

Roda os 15 testes de API e segurança. Eles usam um banco temporário e um servidor SMTP falso, não leem o `.env` e
não tocam em `data/`.

### GitHub
O repositório deve ficar **privado**. O `.gitignore` impede o envio de `.env`, `data/` (banco com dados pessoais),
logs, builds e, para o futuro, de keystores e `google-services.json`. O workflow `.github/workflows/test.yml`
executa `npm test` com Node 22 a cada push na `main` e em pull requests. Mantenha ativos o *secret scanning* e o
*push protection* do GitHub.

## O que o servidor garante
| Requisito | Como é feito |
|---|---|
| Campos obrigatórios | Validados no servidor (e no navegador, para resposta rápida) |
| E-mail já cadastrado | `UNIQUE` no banco + resposta 409. Normaliza maiúsculas e, no Gmail, ignora pontos e `+etiqueta` (`a.b+x@gmail.com` = `ab@gmail.com`), então não dá para criar várias contas com a mesma caixa |
| Senha segura | scrypt (N=32768, r=8, p=1), sal aleatório por senha, comparação em tempo constante. Nunca em texto puro |
| Sessão protegida | Token aleatório de 256 bits em cookie `HttpOnly` + `SameSite=Strict` (+ `Secure` e prefixo `__Host-` em produção). No banco fica só o hash do token. Validade de 7 dias (persiste ao fechar e abrir o app), máximo de 5 sessões por conta |
| Logout | Apaga a sessão no servidor |
| CSRF | Exige JSON e `Origin` igual ao site, além do cookie `SameSite=Strict` |
| Força bruta | Limite por IP e por e-mail em login, cadastro e recuperação; erro idêntico para e-mail inexistente |
| Recuperação de senha | Código de 6 dígitos **por e-mail**, válido por 10 min, uso único, no máximo 5 tentativas, guardado só como HMAC. Ao redefinir, **todas as sessões da conta são encerradas**. A resposta é a mesma exista ou não o e-mail |
| Cabeçalhos | CSP restritiva (sem scripts inline), `X-Frame-Options`, `nosniff`, HSTS em produção |

## E-mail de recuperação (obrigatório em produção)
O servidor tem um cliente SMTP próprio (TLS direto na 465 ou STARTTLS na 587). Configure `SMTP_HOST`, `SMTP_PORT`,
`SMTP_MODE`, `SMTP_USER`, `SMTP_PASS` e `SMTP_FROM` no `.env`. No Gmail use uma **senha de app**
(Conta Google > Segurança > Verificação em 2 etapas > Senhas de app). Sem SMTP, em produção o código **não é enviado**
(e nunca é gravado em log). `SMTP_MODE=plain` (sem criptografia) só funciona fora de produção, para testes.
`EMAIL_DOMAINS=gmail.com` restringe o cadastro a Gmail; vazio aceita qualquer e-mail válido.

**Ainda não existe:** confirmação do e-mail no cadastro (quem se cadastra com um e-mail não prova que é dono dele).

## Publicar
- Use sempre **HTTPS** (Caddy, Nginx, Cloudflare). O servidor escuta em `127.0.0.1`; coloque o proxy na frente.
- Atrás de proxy que sobrescreve `X-Forwarded-For`, use `TRUST_PROXY=1`. Caso contrário deixe `0`.
- Faça backup de `data/zonaxit.db` (contém nomes, e-mails e hashes). O `.gitignore` já exclui `data/` e `.env` do Git; nunca os envie a nenhum repositório.
- Em várias instâncias, troque o limite de tentativas (em memória) por Redis.
- Nome e e-mail são dados pessoais (LGPD): publique uma política de privacidade e deixe claro o uso dos dados.

## Estrutura
    server.js        API + arquivos estáticos
    .github/         workflow de testes (GitHub Actions)
    public/          index.html e app.js (painel)
    test/            testes automatizados da API
    data/            banco SQLite (criado ao iniciar)
