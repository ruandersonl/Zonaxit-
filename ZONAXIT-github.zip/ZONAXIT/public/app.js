const CATS=[
{id:"mira",n:"MIRA",o:["Headtrick","Auxílio de mira","100% HS","Mira leve"]},
{id:"visual",n:"VISUAL",o:["ESP","ESP Vida","ESP Esqueleto","ESP Nome","Tela Esticada"]},
{id:"aimbot",n:"AIMBOT",o:["Aimbot","Aimbot Linha","Aimbot Lite"],extra:true},
{id:"desempenho",n:"DESEMPENHO",o:["120 FPS","60 FPS"]},
{id:"perso",n:"PERSONALIZAÇÃO",o:["Atrás da Parede","Gelo Invertido","Gelo Automático"]}
];
const svg=p=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
const IC={
  mira:svg('<circle cx="12" cy="12" r="7"/><path d="M12 2v4M12 18v4M2 12h4M18 12h4"/>'),
  visual:svg('<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>'),
  aimbot:svg('<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3"/>'),
  desempenho:svg('<path d="M4 18a9 9 0 1 1 16 0"/><path d="M12 14l4-5"/>'),
  perso:svg('<path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/>')
};
const SN={mira:"MIRA",visual:"VISUAL",aimbot:"AIMBOT",desempenho:"DESEMP.",perso:"PERSONAL."};
const cnt=c=>c.o.filter(o=>S.on[o]).length;
const head=c=>`<div class="chead"><i class="ic">${IC[c.id]}</i><div><h2>${c.n}</h2><small>Opções da categoria</small></div><b class="cc" data-c="${c.id}">${cnt(c)}/${c.o.length}</b></div>`;
function stats(){
  const all=CATS.flatMap(c=>c.o),on=all.filter(o=>S.on[o]).length,t=all.length,el=document.getElementById("stats");
  if(!el.firstChild)el.innerHTML='<div class="stat"><b id="s-t"></b><span>TOTAL</span></div><div class="stat on"><b id="s-a"></b><span>ATIVADAS</span></div><div class="stat"><b id="s-d"></b><span>DESATIVADAS</span></div><div class="pbar"><i id="sp"></i></div>';
  [["s-t",t],["s-a",on],["s-d",t-on]].forEach(([id,v])=>{const b=document.getElementById(id);if(b.textContent!=v){b.textContent=v;b.classList.remove("bump");void b.offsetWidth;b.classList.add("bump")}});
  document.getElementById("sp").style.width=on/t*100+"%";
  CATS.forEach(c=>{const x=document.querySelector(`.cc[data-c="${c.id}"]`);if(x)x.textContent=cnt(c)+"/"+c.o.length});
}
const KEYBASE="zonaxit-v1";
let KEY=null;
const DEF=()=>({tab:"mira",on:{},fov:90,target:"Cabeça"});
let S=DEF();
function loadFor(uid){
  KEY=KEYBASE+":"+uid;S=DEF();
  try{const r=localStorage.getItem(KEY);
    if(r){const d=JSON.parse(r);if(d&&typeof d==="object")S=Object.assign(S,d);if(!S.on||typeof S.on!=="object")S.on={};S.fov=Math.min(360,Math.max(0,+S.fov||0));if(!CATS.some(c=>c.id===S.tab))S.tab="mira";if(S.target!=="Pescoço")S.target="Cabeça"}}catch(e){}
}
const save=()=>{if(!KEY)return;try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}};
const $=id=>document.getElementById(id);

function render(){
  $("nav").innerHTML=CATS.map(c=>`<button class="${c.id===S.tab?"on":""}" data-t="${c.id}">${IC[c.id]}<span>${SN[c.id]}</span></button>`).join("");
  $("main").innerHTML=CATS.map(c=>`<section class="panel ${c.id===S.tab?"on":""}">${head(c)}`+
    c.o.map((o,i)=>`<div class="card ${S.on[o]?"active":""}" style="--i:${i+1}"><div class="row"><span class="lb"><i class="ic">${IC[c.id]}</i>${o}<em class="st ${S.on[o]?"on":""}">${S.on[o]?"ON":"OFF"}</em></span><button class="sw ${S.on[o]?"on":""}" data-o="${o}" aria-label="${o}"${unsup(o)?" disabled title=\"Sem suporte no jogo conectado\"":""}></button></div>`+
    (c.extra&&o==="Aimbot"?`<div class="sub"><div>Alvo</div><div class="seg"><button data-g="Pescoço" class="${S.target==="Pescoço"?"on":""}">PESCOÇO</button><button data-g="Cabeça" class="${S.target==="Cabeça"?"on":""}">CABEÇA</button></div>
    <div class="fov" style="margin-top:16px"><span>Controle FOV</span><output id="fv">${S.fov}°</output></div><input type="range" id="fov" min="0" max="360" value="${S.fov}" style="--p:${S.fov/3.6}%"></div>`:"")+`</div>`).join("")+`</section>`).join("");
}
document.addEventListener("click",e=>{
  const t=e.target.closest("[data-t],[data-o],[data-g]");if(!t)return;
  if(t.dataset.t)S.tab=t.dataset.t;
  if(t.dataset.o){toggleOpt(t.dataset.o,t);return}
  if(t.dataset.g){S.target=t.dataset.g;pushNow({aimTarget:S.target==="Pescoço"?"neck":"head"})}
  save();render();
});
document.addEventListener("input",e=>{
  if(e.target.id==="fov"){S.fov=+e.target.value;$("fv").textContent=S.fov+"°";e.target.style.setProperty("--p",S.fov/3.6+"%");save();pushFov()}
});
function paint(sw,on){
  const card=sw.closest(".card"),st=card.querySelector(".st");
  sw.classList.toggle("on",on);card.classList.toggle("active",on);
  st.textContent=on?"ON":"OFF";st.classList.toggle("on",on);
  card.classList.remove("pop");void card.offsetWidth;card.classList.add("pop");stats();
}
$("alloff").onclick=()=>{
  S.on={};save();stats();
  document.querySelectorAll(".sw.on").forEach((s,i)=>setTimeout(()=>paint(s,false),i*50));
  pushNow(allSettings());
};
/* ===== INTEGRAÇÃO COM O JOGO (ponte "zonaxit-bridge") =====
   O painel só se comunica com páginas do MESMO site que implementam o protocolo da ponte
   (veja README). Nada é aplicado sem confirmação do jogo. */
const KEY_OF={"Headtrick":"headSnap","Auxílio de mira":"aimAssist","100% HS":"alwaysHeadshot","Mira leve":"lightAim","ESP":"espBoxes","ESP Vida":"espHealth","ESP Esqueleto":"espSkeleton","ESP Nome":"espNames","Tela Esticada":"stretch","Aimbot":"aimbot","Aimbot Linha":"aimLine","Aimbot Lite":"aimbotLite","120 FPS":"fps120","60 FPS":"fps60","Atrás da Parede":"seeThroughWalls","Gelo Invertido":"iceInvert","Gelo Automático":"iceAuto"};
const LABEL_OF=Object.fromEntries(Object.entries(KEY_OF).map(([l,k])=>[k,l]));
LABEL_OF.fov="Controle FOV";LABEL_OF.aimTarget="Alvo (pescoço/cabeça)";
const game={connected:false,supports:new Set(),seen:0};
const pending=new Map();
let bridge=null,seq=0,timer;
try{bridge=new BroadcastChannel("zonaxit-bridge")}catch(e){}
const unsup=o=>game.connected&&!game.supports.has(KEY_OF[o]);
const send=m=>{if(!bridge)return false;try{bridge.postMessage(m);return true}catch(e){return false}};
function allSettings(){const o={};for(const[l,k]of Object.entries(KEY_OF))o[k]=!!S.on[l];o.fov=S.fov;o.aimTarget=S.target==="Pescoço"?"neck":"head";return o}
const pushNow=settings=>{if(game.connected)send({t:"apply",seq:++seq,settings})};
let fovT=0;const pushFov=()=>{clearTimeout(fovT);fovT=setTimeout(()=>pushNow({fov:S.fov}),40)};
const paintByLabel=(l,on)=>{const s=document.querySelector(`.sw[data-o="${l}"]`);if(s)paint(s,on)};
function toggleOpt(label,sw){
  const on=!S.on[label];S.on[label]=on;const upd={[KEY_OF[label]]:on};
  const other=label==="120 FPS"?"60 FPS":label==="60 FPS"?"120 FPS":null;   // só um limite de FPS por vez
  if(on&&other&&S.on[other]){S.on[other]=false;upd[KEY_OF[other]]=false;paintByLabel(other,false)}
  save();paint(sw,on);pushNow(upd);
}
function setGame(on,info){
  const sup=info?info.supports.join():"",changed=on!==game.connected||(on&&[...game.supports].join()!==sup);
  game.connected=on;game.supports=on&&info?new Set(info.supports):new Set();
  $("gstat").textContent=on?"JOGO CONECTADO":"JOGO OFFLINE";
  $("gdot").classList.toggle("off",!on);
  if(changed&&user){render();stats()}
}
if(bridge){
  bridge.onmessage=ev=>{
    const m=ev.data||{};
    if(m.t==="hello"&&Array.isArray(m.supports)&&user){game.seen=Date.now();const was=game.connected;setGame(true,m);if(!was)pushNow(allSettings())}
    else if(m.t==="ack"){const p=pending.get(m.seq);if(p){pending.delete(m.seq);p(m)}}
  };
  setInterval(()=>{if(!user)return;send({t:"ping"});if(game.connected&&Date.now()-game.seen>7000)setGame(false)},3000);
}

function request(settings,ms=2500){
  return new Promise(res=>{
    const id=++seq,to=setTimeout(()=>{pending.delete(id);res(null)},ms);
    pending.set(id,m=>{clearTimeout(to);res(m)});
    if(!send({t:"apply",seq:id,settings})){clearTimeout(to);pending.delete(id);res(null)}
  });
}
function result(ok,title,msg){$("mb").className=ok?"ok":"fail";$("mt").textContent=title;$("mp").textContent=msg;$("mc").style.display="block"}
$("apply").onclick=async()=>{
  $("modal").classList.add("on");$("mc").style.display="none";$("mb").className="ind";$("mt").textContent="Aplicando no jogo…";$("mp").textContent="";
  if(!game.connected)return result(false,"Nenhum jogo conectado","Abra o seu jogo (uma página do mesmo site que use a ponte zonaxit-bridge) e tente de novo.");
  const want=allSettings(),ack=await request(want);
  if(!ack)return result(false,"O jogo não respondeu","Sem confirmação em 2,5 s. Confira se o jogo está aberto e tente novamente.");
  const bad=Object.keys(want).filter(k=>JSON.stringify(ack.settings&&ack.settings[k])!==JSON.stringify(want[k]));
  if(bad.length)return result(false,"Aplicado com falhas",bad.map(k=>`${LABEL_OF[k]||k}: ${(ack.rejected&&ack.rejected[k])||"não confirmado pelo jogo"}`).join(" · "));
  const on=Object.values(want).filter(v=>v===true).length;
  result(true,"APLICADO NO JOGO",`${on} ${on===1?"opção ativa confirmada":"opções ativas confirmadas"} pelo jogo · FOV ${S.fov}° · alvo ${S.target.toLowerCase()}.`);
};
$("mc").onclick=()=>$("modal").classList.remove("on");
const MSG=["Inicializando interface...","Verificando sessão...","Preparando painel..."];
const splash=$("splash"),welcome=$("welcome"),appEl=$("app");

/* ===== AUTENTICAÇÃO (e-mail + senha) =====
   O servidor valida, faz o hash da senha (scrypt) e cria a sessão em cookie HttpOnly.
   Nenhuma senha ou token fica guardado no navegador. */
let user=null,authReady=false,splashDone=false,freshMsg="",toastT;
function toast(t,k){const e=$("toast");e.textContent=t;e.className="toast on "+(k||"");clearTimeout(toastT);toastT=setTimeout(()=>e.classList.remove("on"),3500)}
async function api(path,body){
  const o={method:body===undefined?"GET":"POST",credentials:"same-origin",headers:{}};
  if(body!==undefined){o.headers["Content-Type"]="application/json";o.body=JSON.stringify(body)}
  try{o.signal=AbortSignal.timeout(8000)}catch(e){}
  try{const r=await fetch("/api/"+path,o);let d={};try{d=await r.json()}catch(e){}return{ok:r.ok,status:r.status,data:d}}
  catch(e){return{ok:false,status:0,data:{error:"Sem conexão com o servidor."}}}
}
const emailOk=s=>s.length<=254&&/^[^\s@]{1,64}@[^\s@]+\.[^\s@]{2,}$/.test(s);
const forms=["login","register","recover"].map(v=>$("f-"+v));
let recStep=1;
function setRec(n){
  recStep=n;
  document.querySelectorAll("#f-recover [data-s]").forEach(e=>e.hidden=+e.dataset.s!==n);
  $("f-recover").querySelector("button[type=submit]").textContent=n===1?"ENVIAR CÓDIGO":"REDEFINIR SENHA";
}
function view(v){
  forms.forEach(f=>{f.hidden=f.id!=="f-"+v;f.querySelectorAll("input").forEach(i=>i.classList.remove("bad"))});
  document.querySelectorAll(".ferr").forEach(e=>e.textContent="");
  if(v==="recover")setRec(1);
}
function fail(f,msg,field){f.querySelector(".ferr").textContent=msg;f.querySelectorAll("input").forEach(i=>i.classList.toggle("bad",i.dataset.f===field))}
function onSubmit(f,fn){
  f.onsubmit=async e=>{
    e.preventDefault();const b=f.querySelector("button[type=submit]");
    b.disabled=true;f.querySelector(".ferr").textContent="";
    try{await fn(f,f.elements)}finally{b.disabled=false}
  };
}
document.querySelectorAll("[data-v]").forEach(b=>b.onclick=()=>view(b.dataset.v));
document.querySelectorAll(".af input").forEach(i=>i.addEventListener("input",()=>{i.classList.remove("bad");i.form.querySelector(".ferr").textContent=""}));

onSubmit($("f-login"),async(f,x)=>{
  const email=x.email.value.trim(),password=x.password.value;
  if(!email||!password)return fail(f,"Informe e-mail e senha.");
  if(!emailOk(email))return fail(f,"E-mail inválido.","email");
  const r=await api("login",{email,password});
  if(!r.ok)return fail(f,r.data.error||"Não foi possível entrar.");
  freshMsg="Login realizado com sucesso!";user=r.data.user;f.reset();route();
});
onSubmit($("f-register"),async(f,x)=>{
  const name=x.fullname.value.trim().replace(/\s+/g," "),email=x.email.value.trim(),password=x.password.value;
  if(name.split(" ").filter(w=>w.length>1).length<2)return fail(f,"Informe seu nome completo.","name");
  if(!emailOk(email))return fail(f,"E-mail inválido.","email");
  if(password.length<8)return fail(f,"A senha deve ter pelo menos 8 caracteres.","password");
  const r=await api("register",{name,email,password});
  if(!r.ok)return fail(f,r.data.error||"Não foi possível criar a conta.",r.data.field);
  freshMsg="Conta criada com sucesso!";user=r.data.user;f.reset();route();
});
onSubmit($("f-recover"),async(f,x)=>{
  const email=x.email.value.trim();
  if(!emailOk(email))return fail(f,"E-mail inválido.","email");
  if(recStep===1){
    const r=await api("recover/request",{email});
    if(!r.ok)return fail(f,r.data.error||"Não foi possível enviar o código.");
    setRec(2);return toast("Se o e-mail estiver cadastrado, enviamos um código.","ok");
  }
  const code=x.code.value.trim(),password=x.password.value;
  if(!/^\d{6}$/.test(code))return fail(f,"Informe o código de 6 dígitos.","code");
  if(password.length<8)return fail(f,"A senha deve ter pelo menos 8 caracteres.","password");
  const r=await api("recover/reset",{email,code,password});
  if(!r.ok)return fail(f,r.data.error||"Não foi possível redefinir a senha.",r.data.field);
  f.reset();view("login");$("f-login").elements.email.value=email;
  toast("Senha redefinida. Entre com a nova senha.","ok");
});

function enterApp(){
  loadFor(user.id);
  const n=user.name||"Usuário";
  $("pname").textContent=n;$("pmail").textContent=user.email||"";$("pav").textContent=n.charAt(0).toUpperCase();
  render();stats();
  appEl.hidden=false;appEl.removeAttribute("inert");void appEl.offsetWidth;appEl.classList.remove("pre");
  splash.classList.add("out");welcome.classList.remove("on");welcome.classList.add("out");
  if(freshMsg){toast(freshMsg,"ok");freshMsg=""}
}
function showLogin(){
  S=DEF();KEY=null;
  setGame(false);
  ["main","stats","nav"].forEach(i=>$(i).innerHTML="");
  ["pname","pmail","pav"].forEach(i=>$(i).textContent="");
  forms.forEach(f=>f.reset());view("login");
  $("modal").classList.remove("on");clearInterval(timer);
  appEl.classList.add("pre");appEl.hidden=true;appEl.setAttribute("inert","");
  splash.classList.add("out");welcome.classList.remove("out");welcome.classList.add("on");
}
function route(){if(!splashDone||!authReady)return;user?enterApp():showLogin()}

$("logout").onclick=async()=>{
  const r=await api("logout",{});
  if(!r.ok&&r.status!==401)return toast("Não foi possível sair. Tente novamente.","err");
  user=null;route();toast("Sessão encerrada.","ok");
};
document.addEventListener("visibilitychange",async()=>{
  if(document.hidden||!user)return;
  const r=await api("me");
  if(r.ok&&!r.data.user){user=null;route();toast("Sua sessão expirou. Entre novamente.","err")}
});
(async()=>{
  const r=await api("me");
  user=r.ok?r.data.user:null;authReady=true;
  if(r.status===0)toast(r.data.error,"err");
  route();
})();
setTimeout(()=>{if(!authReady){authReady=true;route()}},6000);

let pct=0;
function loadStep(){
  pct=Math.min(authReady?100:60,pct+Math.random()*4+1.5); // só chega a 100% quando a sessão foi verificada
  $("sbar").style.width=pct+"%";$("spct").textContent=Math.floor(pct)+"%";
  $("smsg").textContent=MSG[authReady?2:pct<30?0:1];
  if(pct<100)return setTimeout(loadStep,60);
  setTimeout(()=>{splashDone=true;route()},400);
}
setTimeout(loadStep,500);
