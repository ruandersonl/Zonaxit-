'use strict';
/* ZONAXIT — servidor de autenticação (e-mail + senha). Sem dependências externas.
   Requer Node.js >= 22.9 (usa node:sqlite, crypto.scrypt e fetch nativos). */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { promisify } = require('node:util');
const { DatabaseSync } = require('node:sqlite');
const scrypt = promisify(crypto.scrypt);

/* ---------- Configuração ---------- */
const PROD = process.env.NODE_ENV === 'production';
const PORT = +process.env.PORT || 3000;
const HOST = process.env.HOST || '127.0.0.1';
const SECURE = PROD || process.env.COOKIE_SECURE === '1';      // cookie Secure (exige HTTPS)
const TRUST_PROXY = process.env.TRUST_PROXY === '1';           // só atrás de proxy que sobrescreve X-Forwarded-For
const EMAIL_DOMAINS = (process.env.EMAIL_DOMAINS || '').toLowerCase().split(',').map(x => x.trim()).filter(Boolean); // vazio = qualquer domínio; ex.: gmail.com
const SESSION_DAYS = 7;
const COOKIE = SECURE ? '__Host-zx_session' : 'zx_session';
const DB_FILE = process.env.DB_FILE || path.join(__dirname, 'data', 'zonaxit.db');
const PUBLIC_DIR = path.join(__dirname, 'public');

let SECRET = process.env.APP_SECRET;
if (!SECRET) {
  if (PROD) { console.error('APP_SECRET é obrigatório em produção.'); process.exit(1); }
  SECRET = crypto.randomBytes(32).toString('hex');
  console.warn('[aviso] APP_SECRET não definido: usando segredo temporário (sessões e códigos caem ao reiniciar).');
}
const hmac = s => crypto.createHmac('sha256', SECRET).update(s).digest('hex');

/* ---------- Banco de dados (SQLite) ---------- */
fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
const db = new DatabaseSync(DB_FILE);
db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;');
{ // esquema antigo (login por telefone): preserva os dados em users_legacy_phone e cria a tabela nova
  const cols = db.prepare('PRAGMA table_info(users)').all().map(c => c.name);
  if (cols.includes('phone') && !cols.includes('email')) {
    db.exec('DROP TABLE IF EXISTS sessions; DROP TABLE IF EXISTS resets; ALTER TABLE users RENAME TO users_legacy_phone;');
    console.warn('[aviso] Tabela antiga de usuários (telefone) preservada como users_legacy_phone. Essas contas não entram por e-mail.');
  }
}
db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL, email_key TEXT NOT NULL UNIQUE,
  pass_hash TEXT NOT NULL, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(
  token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS resets(
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  code_hash TEXT NOT NULL, expires_at INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0);
`);
const q = {
  byKey: db.prepare('SELECT * FROM users WHERE email_key=?'),
  insUser: db.prepare('INSERT INTO users(name,email,email_key,pass_hash,created_at) VALUES(?,?,?,?,?)'),
  updPass: db.prepare('UPDATE users SET pass_hash=? WHERE id=?'),
  insSess: db.prepare('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)'),
  trimSess: db.prepare('DELETE FROM sessions WHERE user_id=? AND token_hash NOT IN (SELECT token_hash FROM sessions WHERE user_id=? ORDER BY expires_at DESC LIMIT 5)'),
  sessUser: db.prepare('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?'),
  delSess: db.prepare('DELETE FROM sessions WHERE token_hash=?'),
  delUserSess: db.prepare('DELETE FROM sessions WHERE user_id=?'),
  upsReset: db.prepare('INSERT INTO resets(user_id,code_hash,expires_at,attempts) VALUES(?,?,?,0) ON CONFLICT(user_id) DO UPDATE SET code_hash=excluded.code_hash,expires_at=excluded.expires_at,attempts=0'),
  getReset: db.prepare('SELECT * FROM resets WHERE user_id=?'),
  incReset: db.prepare('UPDATE resets SET attempts=attempts+1 WHERE user_id=?'),
  delReset: db.prepare('DELETE FROM resets WHERE user_id=?'),
  purgeS: db.prepare('DELETE FROM sessions WHERE expires_at<?'),
  purgeR: db.prepare('DELETE FROM resets WHERE expires_at<?'),
};

/* ---------- Hash de senha (scrypt, sal único por senha) ---------- */
const N = 32768, R = 8, P = 1, KEYLEN = 64;
async function hashPw(pw) {
  const salt = crypto.randomBytes(16);
  const h = await scrypt(pw.normalize('NFKC'), salt, KEYLEN, { N, r: R, p: P, maxmem: 128 * N * R * 2 });
  return `scrypt$${N}$${R}$${P}$${salt.toString('base64')}$${h.toString('base64')}`;
}
async function verifyPw(pw, stored) {
  const [, n, r, p, s, h] = stored.split('$');
  const want = Buffer.from(h, 'base64');
  const got = await scrypt(pw.normalize('NFKC'), Buffer.from(s, 'base64'), want.length,
    { N: +n, r: +r, p: +p, maxmem: 128 * +n * +r * 2 });
  return crypto.timingSafeEqual(got, want);
}
const DUMMY = hashPw(crypto.randomBytes(8).toString('hex')); // evita diferença de tempo para e-mail inexistente

/* ---------- Validação ---------- */
const EMAIL_RE = /^[a-z0-9.!#$%&'*+/=?^_`{|}~-]{1,64}@[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+$/;
function normEmail(raw) {
  if (typeof raw !== 'string' || raw.length > 254) return null;
  const e = raw.normalize('NFKC').trim().toLowerCase();
  if (!EMAIL_RE.test(e) || e.includes('..')) return null;
  const [local, domain] = e.split('@');
  if (local.startsWith('.') || local.endsWith('.')) return null;
  if (EMAIL_DOMAINS.length && !EMAIL_DOMAINS.includes(domain)) return null;
  return e;
}
// Chave única: no Gmail, pontos e "+etiqueta" não mudam a caixa de entrada (a.b+x@gmail.com = ab@gmail.com)
function emailKey(e) {
  let [l, d] = e.split('@');
  if (d === 'googlemail.com') d = 'gmail.com';
  if (d === 'gmail.com') l = l.split('+')[0].replace(/\./g, '');
  return l + '@' + d;
}
function cleanName(n) {
  if (typeof n !== 'string') return null;
  n = n.normalize('NFKC').replace(/\s+/g, ' ').trim();
  if (n.length < 5 || n.length > 80 || !/^[\p{L}\p{M}][\p{L}\p{M}'.\- ]*$/u.test(n)) return null;
  return n.split(' ').filter(w => w.length > 1).length >= 2 ? n : null;
}
const WEAK = new Set(['12345678', '123456789', '1234567890', 'password', 'senha123', '11111111', '00000000', 'qwertyui', 'abcd1234']);
function pwError(p, email) {
  if (typeof p !== 'string' || p.length < 8 || p.length > 128) return 'A senha deve ter entre 8 e 128 caracteres.';
  if (WEAK.has(p.toLowerCase()) || /^(.)\1+$/.test(p) || p.toLowerCase() === email || p.toLowerCase() === email.split('@')[0]) return 'Senha muito fácil de adivinhar.';
  return null;
}

/* ---------- Limite de tentativas (em memória) ---------- */
const hits = new Map();
function limited(key, max, windowMs) {
  const now = Date.now(); let e = hits.get(key);
  if (!e || e.t < now) { e = { n: 0, t: now + windowMs }; hits.set(key, e); }
  return ++e.n > max;
}
setInterval(() => {
  const now = Date.now();
  for (const [k, e] of hits) if (e.t < now) hits.delete(k);
  q.purgeS.run(now); q.purgeR.run(now);
}, 60000).unref();

/* ---------- E-mail (cliente SMTP mínimo) ---------- */
const net = require('node:net'), tls = require('node:tls');
function smtpConfigured() { return !!(process.env.SMTP_HOST && process.env.SMTP_FROM); }
async function smtpSend(to, subject, text) {
  const { SMTP_HOST: host, SMTP_USER: user, SMTP_PASS: pass, SMTP_FROM: from } = process.env;
  const mode = (process.env.SMTP_MODE || 'starttls').toLowerCase();   // tls (465) | starttls (587) | plain (só fora de produção)
  const port = +process.env.SMTP_PORT || (mode === 'tls' ? 465 : mode === 'plain' ? 25 : 587);
  if (mode === 'plain' && PROD) throw new Error('SMTP sem criptografia não é permitido em produção');
  const addr = /<([^>]+)>/.exec(from) ? /<([^>]+)>/.exec(from)[1] : from;
  if (/[\r\n]/.test(to + from + subject)) throw new Error('cabeçalho inválido');
  let sock = await new Promise((ok, bad) => {
    const s = mode === 'tls' ? tls.connect({ host, port, servername: host }, () => ok(s)) : net.connect({ host, port }, () => ok(s));
    s.once('error', bad); s.setTimeout(15000, () => bad(new Error('smtp timeout')));
  });
  let buf = '';
  const read = () => new Promise((ok, bad) => {
    const chk = () => { if (/(^|\r\n)\d{3}( [^\r\n]*)?\r\n$/.test(buf)) { sock.off('data', on); sock.off('error', bad); const r = buf; buf = ''; ok(r); } };
    const on = d => { buf += d; chk(); };
    sock.on('data', on); sock.once('error', bad); chk();
  });
  const cmd = async (line, ok) => { sock.write(line + '\r\n'); const r = await read(); if (!ok.includes(r.slice(0, 3))) throw new Error('smtp ' + r.slice(0, 3)); return r; };
  try {
    let r = await read(); if (!r.startsWith('220')) throw new Error('smtp ' + r.slice(0, 3));
    await cmd('EHLO zonaxit', ['250']);
    if (mode === 'starttls') {
      await cmd('STARTTLS', ['220']);
      sock = await new Promise((ok, bad) => { const t = tls.connect({ socket: sock, servername: host }, () => ok(t)); t.once('error', bad); });
      await cmd('EHLO zonaxit', ['250']);
    }
    if (user) await cmd('AUTH PLAIN ' + Buffer.from(`\0${user}\0${pass || ''}`).toString('base64'), ['235']);
    await cmd(`MAIL FROM:<${addr}>`, ['250']);
    await cmd(`RCPT TO:<${to}>`, ['250', '251']);
    await cmd('DATA', ['354']);
    const b64 = s => Buffer.from(s, 'utf8').toString('base64');
    const msg = [`From: ${from}`, `To: <${to}>`, `Subject: =?UTF-8?B?${b64(subject)}?=`, `Date: ${new Date().toUTCString()}`,
      `Message-ID: <${crypto.randomUUID()}@zonaxit>`, 'MIME-Version: 1.0', 'Content-Type: text/plain; charset=utf-8',
      'Content-Transfer-Encoding: base64', '', b64(text).replace(/.{1,76}/g, '$&\r\n').trimEnd()].join('\r\n');
    await cmd(msg + '\r\n.', ['250']);
    sock.write('QUIT\r\n');
  } finally { sock.end(); }
}
async function sendMail(to, subject, text) {
  if (smtpConfigured()) return smtpSend(to, subject, text);
  if (!PROD) { console.log(`[DEV-MAIL] para ${to}: ${text}`); return; } // fora de produção o código aparece no console
  throw new Error('SMTP não configurado');
}

/* ---------- HTTP helpers ---------- */
const SEC = {
  'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'X-Frame-Options': 'DENY',
  'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
  ...(SECURE ? { 'Strict-Transport-Security': 'max-age=31536000; includeSubDomains' } : {}),
};
function send(res, status, obj, extra = {}) {
  const b = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Content-Length': Buffer.byteLength(b), ...SEC, ...extra });
  res.end(b);
}
const httpErr = (status, message) => Object.assign(new Error(message), { status });
function readBody(req) {
  return new Promise((ok, bad) => {
    let n = 0, over = false; const c = [];
    req.on('data', d => { n += d.length; if (n > 4096) over = true; else c.push(d); });
    req.on('end', () => {
      if (over) return bad(httpErr(413, 'Requisição muito grande.'));
      try { const b = JSON.parse(Buffer.concat(c).toString('utf8') || '{}'); ok(b && typeof b === 'object' ? b : {}); }
      catch { bad(httpErr(400, 'Requisição inválida.')); }
    });
    req.on('error', bad);
  });
}
function clientIp(req) {
  if (TRUST_PROXY) { const x = (req.headers['x-forwarded-for'] || '').split(',').pop().trim(); if (x) return x; }
  return req.socket.remoteAddress || 'ip';
}
const cookieStr = (v, age) => `${COOKIE}=${v}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${age}${SECURE ? '; Secure' : ''}`;
function getToken(req) {
  const c = (req.headers.cookie || '').split(';').map(s => s.trim()).find(s => s.startsWith(COOKIE + '='));
  return c ? c.slice(COOKIE.length + 1) : null;
}
const authUser = req => { const t = getToken(req); return t ? q.sessUser.get(hmac(t), Date.now()) : null; };
const pub = u => ({ id: u.id, name: u.name, email: u.email });
function newSession(userId) {
  const tok = crypto.randomBytes(32).toString('base64url');
  q.insSess.run(hmac(tok), userId, Date.now() + SESSION_DAYS * 864e5);
  q.trimSess.run(userId, userId);
  return cookieStr(tok, SESSION_DAYS * 86400);
}

/* ---------- Rotas da API ---------- */
async function api(req, res, p) {
  const ip = clientIp(req);
  if (req.method === 'GET' && p === '/api/me') {
    const u = authUser(req);
    return send(res, 200, { user: u ? pub(u) : null }); // 200 com user:null evita erro 401 no console antes do login
  }
  if (req.method !== 'POST') return send(res, 405, { error: 'Método não permitido.' });
  // Proteção CSRF: JSON + Origin igual ao host (além do cookie SameSite=Strict)
  let origin = null; try { origin = new URL(req.headers.origin).host; } catch {}
  if (!(req.headers['content-type'] || '').startsWith('application/json') || origin !== req.headers.host)
    return send(res, 403, { error: 'Origem não permitida.' });
  const b = await readBody(req);

  if (p === '/api/register') {
    const name = cleanName(b.name), email = normEmail(b.email);
    if (!name) return send(res, 400, { error: 'Informe seu nome completo.', field: 'name' });
    if (!email) return send(res, 400, { error: EMAIL_DOMAINS.length ? `Use um e-mail ${EMAIL_DOMAINS.join(' ou ')}.` : 'E-mail inválido.', field: 'email' });
    const pe = pwError(b.password, email);
    if (pe) return send(res, 400, { error: pe, field: 'password' });
    if (limited('r:ip:' + ip, 10, 3600e3)) return send(res, 429, { error: 'Muitas tentativas. Tente mais tarde.' }); // só conta cadastros com dados válidos
    const key = emailKey(email);
    if (q.byKey.get(key)) return send(res, 409, { error: 'Este e-mail já está cadastrado.', field: 'email' });
    const hash = await hashPw(b.password);
    let id;
    try { id = q.insUser.run(name, email, key, hash, Date.now()).lastInsertRowid; }
    catch (e) { if (/UNIQUE/.test(e.message)) return send(res, 409, { error: 'Este e-mail já está cadastrado.', field: 'email' }); throw e; }
    return send(res, 201, { user: { id: Number(id), name, email } }, { 'Set-Cookie': newSession(Number(id)) });
  }

  if (p === '/api/login') {
    const email = normEmail(b.email), bad = { error: 'E-mail ou senha inválidos.' };
    if (!email || typeof b.password !== 'string' || b.password.length > 128) return send(res, 400, bad);
    const key = emailKey(email);
    if (limited('l:ip:' + ip, 40, 15 * 60e3) || limited('l:em:' + key, 10, 15 * 60e3))
      return send(res, 429, { error: 'Muitas tentativas. Aguarde alguns minutos.' });
    const u = q.byKey.get(key);
    const ok = await verifyPw(b.password, u ? u.pass_hash : await DUMMY);
    if (!u || !ok) return send(res, 401, bad);
    return send(res, 200, { user: pub(u) }, { 'Set-Cookie': newSession(u.id) });
  }

  if (p === '/api/logout') {
    const t = getToken(req); if (t) q.delSess.run(hmac(t));
    return send(res, 200, { ok: true }, { 'Set-Cookie': cookieStr('', 0) });
  }

  if (p === '/api/recover/request') {
    const email = normEmail(b.email);
    if (!email) return send(res, 400, { error: 'E-mail inválido.' });
    const key = emailKey(email);
    if (limited('q:ip:' + ip, 10, 3600e3) || limited('q:em:' + key, 3, 3600e3))
      return send(res, 429, { error: 'Muitas solicitações. Tente novamente mais tarde.' });
    const u = q.byKey.get(key);
    if (u) {
      const code = String(crypto.randomInt(0, 1e6)).padStart(6, '0');
      q.upsReset.run(u.id, hmac(u.id + ':' + code), Date.now() + 10 * 60e3);
      sendMail(u.email, 'ZONAXIT — código de recuperação de senha',
        `Seu código de recuperação é ${code}.\nEle vale por 10 minutos e só pode ser usado uma vez.\nSe você não pediu, ignore este e-mail: sua senha continua a mesma.`)
        .catch(() => console.error('[email] falha ao enviar'));
    }
    return send(res, 200, { message: 'Se o e-mail estiver cadastrado, enviaremos um código.' }); // mesma resposta existindo ou não
  }

  if (p === '/api/recover/reset') {
    const email = normEmail(b.email), generic = { error: 'Código inválido ou expirado.' };
    if (!email || typeof b.code !== 'string' || !/^\d{6}$/.test(b.code)) return send(res, 400, generic);
    const pe = pwError(b.password, email);
    if (pe) return send(res, 400, { error: pe, field: 'password' });
    const key = emailKey(email);
    if (limited('x:ip:' + ip, 20, 3600e3) || limited('x:em:' + key, 10, 3600e3))
      return send(res, 429, { error: 'Muitas tentativas. Tente novamente mais tarde.' });
    const u = q.byKey.get(key), rs = u && q.getReset.get(u.id);
    if (!rs || rs.expires_at < Date.now() || rs.attempts >= 5) { if (rs) q.delReset.run(u.id); return send(res, 400, generic); }
    const good = crypto.timingSafeEqual(Buffer.from(hmac(u.id + ':' + b.code)), Buffer.from(rs.code_hash));
    if (!good) { q.incReset.run(u.id); return send(res, 400, generic); }
    q.updPass.run(await hashPw(b.password), u.id);
    q.delReset.run(u.id);
    q.delUserSess.run(u.id); // encerra todas as sessões ativas
    return send(res, 200, { message: 'Senha redefinida. Entre com a nova senha.' });
  }
  return send(res, 404, { error: 'Não encontrado.' });
}

/* ---------- Servidor ---------- */
const STATIC = { // [arquivo, tipo]
  '/': ['index.html', 'text/html; charset=utf-8'], '/app.js': ['app.js', 'text/javascript; charset=utf-8'],
};
const server = http.createServer(async (req, res) => {
  try {
    const p = new URL(req.url, 'http://x').pathname;
    if (p.startsWith('/api/')) return await api(req, res, p);
    if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, { error: 'Método não permitido.' });
    const f = STATIC[p];
    if (!f) { res.writeHead(p === '/favicon.ico' ? 204 : 404, SEC); return res.end(); }
    const data = await fs.promises.readFile(path.join(PUBLIC_DIR, f[0]));
    res.writeHead(200, { 'Content-Type': f[1], 'Cache-Control': 'no-cache', ...SEC });
    res.end(req.method === 'HEAD' ? undefined : data);
  } catch (e) {
    if (!e.status) console.error(e);
    if (!res.headersSent) send(res, e.status || 500, { error: e.status ? e.message : 'Erro interno.' });
  }
});
if (PROD && !smtpConfigured()) console.warn('[aviso] SMTP_HOST/SMTP_FROM não definidos: a recuperação de senha por e-mail NÃO vai funcionar.');
server.listen(PORT, HOST, () => console.log(`ZONAXIT em http://${HOST}:${PORT}`));
