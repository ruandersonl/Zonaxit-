'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const net = require('node:net');
const fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'zx-'));
const wait = ms => new Promise(r => setTimeout(r, ms));
const procs = [];

/* servidor SMTP falso (só para os testes): guarda as mensagens recebidas */
const inbox = [];
const smtp = net.createServer(sock => {
  let data = false, msg = '';
  sock.write('220 mock ESMTP\r\n');
  sock.on('data', d => {
    for (const line of d.toString().split('\r\n')) {
      if (data) { msg += line + '\r\n'; if (line === '.') { data = false; inbox.push(msg); msg = ''; sock.write('250 ok\r\n'); } continue; }
      if (!line) continue;
      if (/^EHLO/i.test(line)) sock.write('250 mock\r\n');
      else if (/^MAIL|^RCPT/i.test(line)) sock.write('250 ok\r\n');
      else if (/^DATA/i.test(line)) { data = true; sock.write('354 go\r\n'); }
      else if (/^QUIT/i.test(line)) sock.end('221 bye\r\n');
      else sock.write('250 ok\r\n');
    }
  });
});
const mail = m => {
  const [head, body] = m.split('\r\n\r\n');
  const text = Buffer.from(body.replace(/\r\n\.\r\n$/, '').replace(/\r\n/g, ''), 'base64').toString('utf8');
  return { to: /^To: <(.+)>$/m.exec(head)[1], subject: /^Subject: (.+)$/m.exec(head)[1], head, text };
};
const lastCode = to => { const m = inbox.map(mail).filter(x => x.to === to).at(-1); return m && /(\d{6})/.exec(m.text)[1]; };

async function start(extra = {}) {
  const port = 3900 + Math.floor(Math.random() * 90), base = `http://127.0.0.1:${port}`;
  const db = extra.DB_FILE || path.join(tmp, 't' + port + '.db');
  const proc = spawn(process.execPath, ['--disable-warning=ExperimentalWarning', path.join(__dirname, '..', 'server.js')], {
    env: { ...process.env, PORT: port, DB_FILE: db, NODE_ENV: 'test', APP_SECRET: 'segredo-de-teste',
      SMTP_HOST: '127.0.0.1', SMTP_PORT: String(smtp.address().port), SMTP_MODE: 'plain', SMTP_FROM: 'ZONAXIT <no-reply@zonaxit.test>', ...extra } });
  const o = { proc, base, db, log: '' };
  proc.stdout.on('data', d => o.log += d); proc.stderr.on('data', d => o.log += d);
  procs.push(proc);
  for (let i = 0; i < 60; i++) { try { await fetch(base + '/api/me'); return o; } catch { await wait(100); } }
  throw new Error('servidor não subiu');
}
let S, BASE;
before(async () => { await new Promise(r => smtp.listen(0, '127.0.0.1', r)); S = await start(); BASE = S.base; });
after(() => { procs.forEach(p => p.kill()); smtp.close(); });

const post = (p, body, cookie, origin = BASE, base = BASE) => fetch(base + '/api/' + p, {
  method: 'POST', body: JSON.stringify(body),
  headers: { 'Content-Type': 'application/json', ...(origin ? { Origin: origin } : {}), ...(cookie ? { Cookie: cookie } : {}) } });
const ck = r => (r.headers.getSetCookie()[0] || '').split(';')[0];
const me = async cookie => { const j = await (await fetch(BASE + '/api/me', { headers: { Cookie: cookie } })).json(); return { status: j.user ? 200 : 401, json: async () => j }; };

const ANA = { name: 'Ana Souza Lima', email: 'Ana.Souza@Gmail.com', password: 'SenhaForte#2026' };
let cookie;

test('cadastro: valida campos obrigatórios', async () => {
  let r = await post('register', { ...ANA, name: 'Ana' }); assert.equal(r.status, 400); assert.equal((await r.json()).field, 'name');
  for (const email of ['', 'sem-arroba', 'a@b', 'a b@gmail.com', 'a..b@gmail.com', '.a@gmail.com', 'a@gmail..com']) {
    r = await post('register', { ...ANA, email }); assert.equal(r.status, 400, email); assert.equal((await r.json()).field, 'email');
  }
  r = await post('register', { ...ANA, password: 'curta' }); assert.equal(r.status, 400); assert.equal((await r.json()).field, 'password');
  r = await post('register', { ...ANA, password: '12345678' }); assert.equal(r.status, 400);
  r = await post('register', { ...ANA, password: 'ana.souza@gmail.com' }); assert.equal(r.status, 400); // senha = e-mail
});

test('cadastro: cria conta, sessão persistente em cookie HttpOnly e /me', async () => {
  const r = await post('register', ANA); assert.equal(r.status, 201);
  const sc = r.headers.getSetCookie()[0];
  assert.match(sc, /HttpOnly/); assert.match(sc, /SameSite=Strict/); assert.match(sc, /Max-Age=\d{6,}/);
  cookie = ck(r);
  const u = (await (await me(cookie)).json()).user;
  assert.equal(u.name, ANA.name); assert.equal(u.email, 'ana.souza@gmail.com');
  assert.equal((await me('')).status, 401);
});

test('e-mail já cadastrado é rejeitado (maiúsculas, pontos e +etiqueta do Gmail)', async () => {
  for (const email of ['ana.souza@gmail.com', 'ANA.SOUZA@GMAIL.COM', 'anasouza@gmail.com', 'ana.souza+loja@gmail.com', 'a.n.a.s.o.u.z.a@googlemail.com']) {
    const r = await post('register', { ...ANA, email }); assert.equal(r.status, 409, email);
    assert.equal((await r.json()).error, 'Este e-mail já está cadastrado.');
  }
});

test('senha nunca fica em texto puro: hash scrypt com sal', () => {
  const d = new DatabaseSync(S.db), row = d.prepare('SELECT * FROM users').get();
  assert.match(row.pass_hash, /^scrypt\$32768\$8\$1\$/);
  assert.ok(!JSON.stringify(row).includes(ANA.password));
  assert.ok(!fs.readFileSync(S.db).includes(ANA.password));
  assert.ok(!cookie.includes(d.prepare('SELECT token_hash FROM sessions').get().token_hash));
});

test('login: senha incorreta e e-mail inexistente dão o mesmo erro; credenciais corretas entram', async () => {
  let r = await post('login', { email: ANA.email, password: 'errada123' }); assert.equal(r.status, 401);
  const e1 = (await r.json()).error;
  r = await post('login', { email: 'ninguem@gmail.com', password: 'qualquer123' }); assert.equal(r.status, 401);
  assert.equal((await r.json()).error, e1);
  r = await post('login', { email: ' ANA.SOUZA@gmail.com ', password: ANA.password }); assert.equal(r.status, 200);
  assert.ok(ck(r).includes('zx_session='));
});

test('logout encerra a sessão no servidor', async () => {
  assert.equal((await post('logout', {}, cookie)).status, 200);
  assert.equal((await me(cookie)).status, 401);
});

test('CSRF: exige JSON e Origin do mesmo site', async () => {
  assert.equal((await post('login', { email: ANA.email, password: ANA.password }, '', null)).status, 403);
  assert.equal((await post('login', { email: ANA.email, password: ANA.password }, '', 'https://evil.example')).status, 403);
  const r = await fetch(BASE + '/api/login', { method: 'POST', body: 'x', headers: { 'Content-Type': 'text/plain', Origin: BASE } });
  assert.equal(r.status, 403);
});

test('recuperação: e-mail enviado só para conta existente, resposta idêntica para ambos', async () => {
  inbox.length = 0;
  const a = await post('recover/request', { email: ANA.email });
  const b = await post('recover/request', { email: 'fantasma@gmail.com' });
  assert.equal(a.status, 200); assert.equal(b.status, 200);
  assert.deepEqual(await a.json(), await b.json());
  await wait(300);
  assert.equal(inbox.length, 1);
  const m = mail(inbox[0]);
  assert.equal(m.to, 'ana.souza@gmail.com'); assert.match(m.head, /Subject: =\?UTF-8\?B\?/); assert.match(m.text, /\b\d{6}\b/);
  assert.ok(!m.text.includes(ANA.password));
});

test('recuperação: código errado bloqueia após 5 tentativas', async () => {
  await post('recover/request', { email: ANA.email }); await wait(300);
  const good = lastCode('ana.souza@gmail.com'), bad = good === '000000' ? '111111' : '000000';
  for (let i = 0; i < 5; i++) assert.equal((await post('recover/reset', { email: ANA.email, code: bad, password: 'NovaSenha#2026' })).status, 400);
  assert.equal((await post('recover/reset', { email: ANA.email, code: good, password: 'NovaSenha#2026' })).status, 400);
});

test('recuperação: código correto troca a senha, derruba sessões e não pode ser reutilizado', async () => {
  const old = ck(await post('login', { email: ANA.email, password: ANA.password }));
  assert.equal((await me(old)).status, 200);
  await post('recover/request', { email: ANA.email }); await wait(300);
  const code = lastCode('ana.souza@gmail.com');
  assert.equal((await post('recover/reset', { email: ANA.email, code, password: '12345678' })).status, 400); // senha fraca
  assert.equal((await post('recover/reset', { email: ANA.email, code, password: 'NovaSenha#2026' })).status, 200);
  assert.equal((await me(old)).status, 401);
  assert.equal((await post('login', { email: ANA.email, password: ANA.password })).status, 401);
  assert.equal((await post('login', { email: ANA.email, password: 'NovaSenha#2026' })).status, 200);
  assert.equal((await post('recover/reset', { email: ANA.email, code, password: 'OutraSenha#2026' })).status, 400);
});

test('limite de tentativas de login (anti força bruta)', async () => {
  let last;
  for (let i = 0; i < 12; i++) last = await post('login', { email: 'forca@gmail.com', password: 'errada' + i + 'xx' });
  assert.equal(last.status, 429);
});

test('o minijogo foi removido: nenhum arquivo de jogo é servido', async () => {
  for (const f of ['/game.html', '/game.js']) assert.equal((await fetch(BASE + f)).status, 404);
});

test('páginas estáticas com cabeçalhos de segurança', async () => {
  const r = await fetch(BASE + '/');
  assert.equal(r.status, 200);
  assert.match(r.headers.get('content-security-policy'), /script-src 'self'/);
  assert.equal(r.headers.get('x-frame-options'), 'DENY');
  assert.equal((await fetch(BASE + '/server.js')).status, 404);
  assert.equal((await fetch(BASE + '/data/zonaxit.db')).status, 404);
});

test('EMAIL_DOMAINS=gmail.com aceita só Gmail', async () => {
  const g = await start({ EMAIL_DOMAINS: 'gmail.com' });
  let r = await post('register', { name: 'Bia Campos', email: 'bia@outlook.com', password: 'SenhaForte#1' }, '', g.base, g.base);
  assert.equal(r.status, 400); assert.match((await r.json()).error, /gmail\.com/);
  r = await post('register', { name: 'Bia Campos', email: 'bia@gmail.com', password: 'SenhaForte#1' }, '', g.base, g.base);
  assert.equal(r.status, 201);
});

test('banco antigo (telefone) é preservado e o novo esquema é criado', async () => {
  const file = path.join(tmp, 'legacy.db'), d = new DatabaseSync(file);
  d.exec("CREATE TABLE users(id INTEGER PRIMARY KEY,name TEXT NOT NULL,phone TEXT NOT NULL UNIQUE,pass_hash TEXT NOT NULL,created_at INTEGER NOT NULL);" +
         "INSERT INTO users(name,phone,pass_hash,created_at) VALUES('Velho Usuario','+5511999990000','scrypt$x',1);");
  d.close();
  const g = await start({ DB_FILE: file });
  const r = await post('register', { name: 'Novo Usuario', email: 'novo@gmail.com', password: 'SenhaForte#1' }, '', g.base, g.base);
  assert.equal(r.status, 201);
  const c = new DatabaseSync(file);
  assert.equal(c.prepare('SELECT phone FROM users_legacy_phone').get().phone, '+5511999990000');
  assert.equal(c.prepare('SELECT email FROM users').get().email, 'novo@gmail.com');
});
